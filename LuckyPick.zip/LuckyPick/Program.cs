﻿using LuckyPick.Data;
using LuckyPick.Repository;
using LuckyPick.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LuckyPick
{
    class Program
    {
        static async Task Main(string[] args)
        {
            //await LuckyPickService.FindExisting();
            //await LuckyPickService.AddAsync();
            //CrmService.Generate();
            await GrandLotto655Service.LuckyPick(30).ConfigureAwait(true);
            //await UltraLotto658Service.LuckyPick(10).ConfigureAwait(true);
            //await LuckyPickService.Search("08-14-19-36-38-41");
            //LuckyPickService.GetAllCombination(59);

            //var sadad = await ConsecutivesRepository.GetAll().ConfigureAwait(false);

            //var duplicates = LuckyPickService.GetDuplicate(await LuckyPickService.GetAllSortData().ConfigureAwait(true));

            //Console.WriteLine(" ");
            //Console.WriteLine(" ");
            //Console.WriteLine(" ");
            //Console.WriteLine(" ");
            //Console.WriteLine(" - Duplicates - ");
            //foreach (var item in duplicates)
            //{
            //    Console.WriteLine(item);
            //}

            //Console.WriteLine(" ");
            //Console.WriteLine(" ");
            //Console.WriteLine(" ");
            //Console.WriteLine(" ");
            //Console.WriteLine(" ");
            //Console.WriteLine(" ");
            //Console.WriteLine("LuckyPick v1.2");
            Console.ReadKey();
        }
    }
}
