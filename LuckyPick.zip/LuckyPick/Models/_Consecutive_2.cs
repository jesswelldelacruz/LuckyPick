﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LuckyPick.Models
{
    public class _Consecutive_2
    {
        [Key]
        public string Combination { get; set; }
    }
}
