﻿using LuckyPick.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LuckyPick.Services
{
    public class UltraLotto658Service
    {
        public async static Task LuckyPick(int div)
        {
            var data = new List<string>();
            //var sortData = DataRepository.GetAll658();
            var allSortData = await LuckyPickService.GetAllSortData().ConfigureAwait(true);
            var allConsecutiveData = await LuckyPickService.GetAllConsecutiveData().ConfigureAwait(true);
            var allSameData = await LuckyPickService.GetAllSameDigitData().ConfigureAwait(true);

            data.AddRange(allSortData);
            data.AddRange(allConsecutiveData);
            data.AddRange(allSameData);

            for (int i = 0; i < div; i++)
            {
                var luckyPick = LuckyPickService.Generate(6, 58);

                while (data.Contains(luckyPick))
                {
                    luckyPick = LuckyPickService.Generate(6, 58);
                }

                LuckyPickService.Export("UltraLotto658", luckyPick);
                Console.WriteLine(luckyPick);
            }
        }

        public async static Task LuckyPickv2()
        {
            var data = new List<string>();
            var allSortData = await LuckyPickService.GetAllSortData().ConfigureAwait(true);
            var allConsecutiveData = await LuckyPickService.GetAllConsecutiveData().ConfigureAwait(true);
            var allSameData = await LuckyPickService.GetAllSameDigitData().ConfigureAwait(true);

            data.AddRange(allSortData);
            data.AddRange(allConsecutiveData);
            data.AddRange(allSameData);

            var combinations = new List<string>();
            var superLuckyPick = new List<string>();

            var count = 0;

            while (superLuckyPick.Count != 6)
            {
                count++;
                var luckyPick = LuckyPickService.Generate(6, 58);

                while (data.Contains(luckyPick))
                {
                    luckyPick = LuckyPickService.Generate(6, 58);
                }

                combinations.Add(luckyPick);

                if (combinations.Where(x => x == luckyPick).Count() > 1)
                {
                    LuckyPickService.Export("UltraLotto658", luckyPick);
                    Console.WriteLine(luckyPick);
                }
                Console.WriteLine(count);
            }
        }
    }
}
