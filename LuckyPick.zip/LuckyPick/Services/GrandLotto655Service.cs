﻿using LuckyPick.Data;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LuckyPick.Services
{
    public class GrandLotto655Service
    {
        public async static Task LuckyPick(int div)
        {
            var data = new List<string>();
            //var sortData = DataRepository.GetAll655();
            var allSortData = await LuckyPickService.GetAllSortData().ConfigureAwait(true);
            var allConsecutiveData = await LuckyPickService.GetAllConsecutiveData().ConfigureAwait(true);
            var allSameData = await LuckyPickService.GetAllSameDigitData().ConfigureAwait(true);

            data.AddRange(allSortData);
            data.AddRange(allConsecutiveData);
            data.AddRange(allSameData);

            for (int i = 0; i < div; i++)
            {
                var luckyPick = LuckyPickService.Generate(6, 55);

                while (data.Contains(luckyPick))
                {
                    luckyPick = LuckyPickService.Generate(6, 55);
                }

                LuckyPickService.Export("GrandLotto655", luckyPick);
                Console.WriteLine(luckyPick);
            }
        }
    }
}
