﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using LuckyPick.Data;
using LuckyPick.Repository;
using System.Threading.Tasks;
using Newtonsoft.Json;
using LuckyPick.Models;

namespace LuckyPick.Services
{
    public class LuckyPickService
    {
        public async static Task Search(string combination)
        {
            var srtCombination = SortDigit(combination);

            var data = new List<string>();
            var allSortData = await GetAllSortData().ConfigureAwait(true);
            var allConsecutiveData = await GetAllConsecutiveData().ConfigureAwait(true);
            var allSameData = await GetAllSameDigitData().ConfigureAwait(true);

            data.AddRange(allSortData);
            data.AddRange(allConsecutiveData);
            data.AddRange(allSameData);

            if (data.Contains(srtCombination))
            {
                Console.WriteLine($"{srtCombination} is already exist");
            }
            else
            {
                Console.WriteLine($"{srtCombination} Good");
            }

        }
        public static string Draw(int max)
        {
            Random rnd = new Random();
            var num = rnd.Next(1, (max + 1));
            return num.ToString().PadLeft(2, '0');
        }

        public static string Generate(int num, int max)
        {
            var luckyDraw = new List<string>();

            for (int i = 0; i < num; i++)
            {
                var n = Draw(max);

                while (luckyDraw.Contains(n))
                {
                    n = Draw(max);
                }
                luckyDraw.Add(n);
            }

            return string.Join("-", luckyDraw.OrderBy(c => int.Parse(c)).ToList());
        }

        public static void Export(string game, string input)
        {
            string path = $@"C:\Lotto";
            string gamePath = path + $@"\{game}.txt";

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            if (!File.Exists(gamePath))
            {
                using (StreamWriter sw = File.CreateText(gamePath))
                {
                    sw.WriteLine(input);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(gamePath))
                {
                    sw.WriteLine(input);
                }
            }
        }

        public async static Task<List<string>> GetAllSortData()
        {
            var data = new List<string>();

            var lotto642 = await DataRepository.GetAll642().ConfigureAwait(true);
            var grandLotto655 = await DataRepository.GetAll655().ConfigureAwait(true);
            var megaLotto645 = await DataRepository.GetAll645().ConfigureAwait(true);
            var superLotto649 = await DataRepository.GetAll649().ConfigureAwait(true);
            var ultraLotto658 = await DataRepository.GetAll658().ConfigureAwait(true);

            data.AddRange(lotto642);
            data.AddRange(megaLotto645);
            data.AddRange(superLotto649);
            data.AddRange(grandLotto655);
            data.AddRange(ultraLotto658);

            return data;
        }

        public async static Task<List<string>> GetAllConsecutiveData()
        {
            var data = new List<string>();

            var consecutive = await DataRepository.GetAllConsecutives().ConfigureAwait(true);
            var consecutives_2 = await DataRepository.GetAllConsecutives_2().ConfigureAwait(true);
            var consecutives_3 = await DataRepository.GetAllConsecutives_3().ConfigureAwait(true);
            var consecutives_4 = await DataRepository.GetAllConsecutives_4().ConfigureAwait(true);
            var consecutives_5 = await DataRepository.GetAllConsecutives_5().ConfigureAwait(true);
            var consecutives_6 = await DataRepository.GetAllConsecutives_6().ConfigureAwait(true);
            var consecutives_7 = await DataRepository.GetAllConsecutives_7().ConfigureAwait(true);
            var consecutives_8 = await DataRepository.GetAllConsecutives_8().ConfigureAwait(true);
            var consecutives_9 = await DataRepository.GetAllConsecutives_9().ConfigureAwait(true);
            var consecutives_10 = await DataRepository.GetAllConsecutives_10().ConfigureAwait(true);
            var consecutives_11 = await DataRepository.GetAllConsecutives_11().ConfigureAwait(true);
            var consecutives_12 = await DataRepository.GetAllConsecutives_12().ConfigureAwait(true);
            var consecutives_13 = await DataRepository.GetAllConsecutives_13().ConfigureAwait(true);
            var consecutives_14 = await DataRepository.GetAllConsecutives_14().ConfigureAwait(true);


            data.AddRange(consecutive);
            data.AddRange(consecutives_2);
            data.AddRange(consecutives_3);
            data.AddRange(consecutives_4);
            data.AddRange(consecutives_5);
            data.AddRange(consecutives_6);
            data.AddRange(consecutives_7);
            data.AddRange(consecutives_8);
            data.AddRange(consecutives_9);
            data.AddRange(consecutives_10);
            data.AddRange(consecutives_11);
            data.AddRange(consecutives_12);
            data.AddRange(consecutives_13);
            data.AddRange(consecutives_14);

            return data.Distinct().ToList();
        }

        public async static Task<List<string>> GetAllSameDigitData()
        {
            var data = new List<string>();

            var sameDigit = await DataRepository.GetAllSameDigits().ConfigureAwait(true);
            var sameLastDigit = await DataRepository.GetAllSameLastDigits().ConfigureAwait(true);

            data.AddRange(sameDigit);
            data.AddRange(sameLastDigit);

            return data.Distinct().ToList();
        }

        public static List<string> GetDuplicate(List<string> data)
        {
            var duplicates = new List<string>();

            var keyValuePairs = data.GroupBy(x => x)
                            .Where(g => g.Count() > 1)
                            .ToDictionary(x => x.Key, y => y.Count());

            foreach (var i in keyValuePairs)
            {
                var duplicate = $"{i.Key} = {i.Value}";
                duplicates.Add(duplicate);
            }

            return duplicates;
        }

        public static void FindConsecutives(string game, string digits, int div, int rep)
        {
            var digitArr = digits.Replace(Environment.NewLine, string.Empty).Split('-');

            int preVal = Convert.ToInt32(digitArr[0]);
            int count = 1;

            for (var i = 0; i < digitArr.Length; i++)
            {
                if (Convert.ToInt32(digitArr[i]) - div == preVal)
                {
                    count += 1;

                    if (count == rep)
                    {
                        Console.WriteLine(digits);
                        Export(game, digits);
                        break;
                    }
                }
                else
                {
                    count = 1;
                }
                preVal = Convert.ToInt32(digitArr[i]);
            }
        }

        public static void FindSameDigit(string game, string digits)
        {
            var digitArr = digits.Replace(Environment.NewLine, string.Empty).Split('-');

            var count = 0;

            foreach (var i in digitArr)
            {
                int a = Convert.ToInt32(i) / 10;
                int b = Convert.ToInt32(i) % 10;

                if (a == b)
                {
                    count += 1;
                }

                if (count >= 3)
                {
                    Console.WriteLine(digits);
                    Export(game, digits);
                }
            }
        }

        public static void FindSameLastDigit(string game, string digits)
        {
            var digitArr = digits.Replace(Environment.NewLine, string.Empty).Split('-');

            var sameLast = digitArr.GroupBy(i => Convert.ToInt32(i) % 10).SingleOrDefault(g => g.Count() >= 4);

            if (sameLast != null)
            {
                Console.WriteLine(digits);
                Export(game, digits);
            }
        }

        public async static Task FindExisting()
        {
            var data = new List<string>();
            //var sortData = DataRepository.GetAll655();
            var allSortData = await GetAllSortData().ConfigureAwait(true);
            var allConsecutiveData = await GetAllConsecutiveData().ConfigureAwait(true);
            var allSameData = await GetAllSameDigitData().ConfigureAwait(true);

            data.AddRange(allSortData);
            data.AddRange(allConsecutiveData);
            data.AddRange(allSameData);

            var digits = $@"04-10-17-20-21-36
02-07-11-20-31-33
05-09-20-23-31-44
07-16-28-34-36-41
04-12-24-25-34-42
15-20-32-41-48-49
05-23-26-38-42-49
06-17-25-38-40-49
04-08-13-37-39-45
04-09-22-24-36-47
04-09-15-30-41-48
02-08-14-15-37-41
11-17-22-25-30-41
01-13-18-29-47-49
06-12-21-30-40-42
02-19-33-36-41-45
47-07-32-13-40-23
07-19-23-31-41-47
13-39-07-46-04-02
02-04-07-13-39-46
01-09-13-30-40-41
03-13-22-31-38-49
13-19-22-24-28-46
01-16-18-19-25-42
21-33-34-37-41-48
15-22-27-33-41-49
09-11-20-26-45-46
05-12-14-20-22-49
04-07-11-26-33-41
03-17-24-26-44-47
15-17-19-30-43-45
09-27-28-32-41-42
01-10-21-38-40-45
14-23-31-34-37-44
03-04-13-20-41-42
04-05-17-24-27-40
07-14-22-23-29-40
02-09-12-15-25-26
01-08-14-23-35-37
01-03-07-09-16-46
02-11-15-21-27-36
08-10-12-21-35-44
20-26-28-43-46-47
03-10-13-20-29-44
07-08-27-34-39-44
08-10-17-24-34-41
07-08-17-35-40-48
05-08-09-18-38-47
09-13-20-21-29-31
03-06-11-20-36-43
01-16-22-23-38-48
10-11-17-22-28-41
05-09-18-23-35-48
13-34-37-40-42-48
11-16-20-21-42-49
02-19-23-25-32-33
07-09-20-26-28-44
02-14-27-38-39-44
03-05-10-11-31-46
10-26-32-34-36-42
04-11-18-22-29-38
17-23-36-41-43-47
08-15-23-43-44-48
08-11-17-37-39-40
11-13-16-20-41-44
07-15-21-27-38-43
04-16-19-28-33-49
09-22-27-34-46-49
02-12-22-40-41-49
14-15-27-28-33-39
03-15-18-19-32-33
02-04-15-23-31-37
02-04-08-14-17-44
02-13-30-34-41-44
18-23-25-35-36-38
02-14-19-22-34-36
10-31-33-42-44-49
07-13-18-20-24-32
24-25-31-42-44-47
02-04-31-38-42-45
";
            var digitArr = digits.Replace("\r", string.Empty).Split('\n');

            foreach (var i in digitArr)
            {
                if (data.Contains(i))
                {
                    Console.WriteLine(i);
                }
            }
        }

        public static void GetAllCombination(int num)
        {
            var arr = new List<string>();
            for (int i = 1; i < num; i++)
            {
                arr.Add(i.ToString().PadLeft(2, '0'));
            }

            arr.DifferentCombinations(6);
        }

        public async static Task AddAsync()
        {
            var lotto642 = new List<Lotto642>
            {
                new Lotto642 {  Combination = "39-02-18-13-12-06", DrawDate =  DateTime.Parse("12/5/2020")},
                new Lotto642 {Combination = "04-01-28-05-27-33", DrawDate =  DateTime.Parse("12/22/2020")},
                new Lotto642 {Combination = "16-41-09-14-33-28", DrawDate =  DateTime.Parse("12/24/2020")},
                new Lotto642 {Combination = "37-23-34-24-15-22", DrawDate =  DateTime.Parse("12/26/2020")},
                new Lotto642 {Combination = "11-25-23-09-31-39", DrawDate =  DateTime.Parse("12/29/2020")},
                new Lotto642 {Combination = "24-25-13-06-34-42", DrawDate =  DateTime.Parse("12/31/2020")},
                new Lotto642 {Combination = "35-23-07-08-09-39", DrawDate =  DateTime.Parse("1/2/2021")},
                new Lotto642 {Combination = "27-36-25-31-34-07", DrawDate =  DateTime.Parse("1/5/2021")},
                new Lotto642 {Combination = "16-03-11-26-25-09", DrawDate =  DateTime.Parse("1/7/2021")},
                new Lotto642 {Combination = "08-33-09-25-34-17", DrawDate =  DateTime.Parse("1/9/2021")},
                new Lotto642 {Combination = "38-33-01-40-27-06", DrawDate =  DateTime.Parse("1/12/2021")},
                new Lotto642 {Combination = "22-04-30-17-33-01", DrawDate =  DateTime.Parse("1/14/2021")},
                new Lotto642 {Combination = "28-09-21-40-29-32", DrawDate =  DateTime.Parse("1/16/2021")},
                new Lotto642 {Combination = "22-13-27-35-16-02", DrawDate =  DateTime.Parse("1/19/2021")},
                new Lotto642 {Combination = "32-01-10-06-41-35", DrawDate =  DateTime.Parse("1/21/2021")},
                new Lotto642 {Combination = "05-02-12-26-28-04", DrawDate =  DateTime.Parse("1/23/2021")},
                new Lotto642 {Combination = "03-09-23-41-19-24", DrawDate =  DateTime.Parse("1/26/2021")},
                new Lotto642 {Combination = "18-35-30-29-26-19", DrawDate =  DateTime.Parse("1/28/2021")},
                new Lotto642 {Combination = "22-18-16-20-13-30", DrawDate =  DateTime.Parse("1/30/2021")},
                new Lotto642 {Combination = "38-25-37-12-09-18", DrawDate =  DateTime.Parse("2/2/2021")},
                new Lotto642 {Combination = "27-13-03-19-37-10", DrawDate =  DateTime.Parse("2/4/2021")},
                new Lotto642 {Combination = "20-07-30-18-05-17", DrawDate =  DateTime.Parse("2/6/2021")},
                new Lotto642 {Combination = "13-17-20-02-05-26", DrawDate =  DateTime.Parse("2/9/2021")},
                new Lotto642 {Combination = "16-30-03-12-21-23", DrawDate =  DateTime.Parse("2/11/2021")},
                new Lotto642 {Combination = "30-41-04-08-27-33", DrawDate =  DateTime.Parse("2/13/2021")},
                new Lotto642 {Combination = "37-36-05-10-08-16", DrawDate =  DateTime.Parse("2/16/2021")},

            };

            var megaLotto645 = new List<MegaLotto645>
            {
                new MegaLotto645 {Combination = "10-44-32-18-14-08", DrawDate =  DateTime.Parse("12/4/2020")},
                new MegaLotto645 {Combination = "01-10-15-27-06-39", DrawDate =  DateTime.Parse("12/21/2020")},
                new MegaLotto645 {Combination = "33-02-43-22-08-24", DrawDate =  DateTime.Parse("12/23/2020")},
                new MegaLotto645 {Combination = "05-08-02-30-04-42", DrawDate =  DateTime.Parse("12/28/2020")},
                new MegaLotto645 {Combination = "06-25-15-29-12-33", DrawDate =  DateTime.Parse("12/30/2020")},
                new MegaLotto645 {Combination = "39-07-27-44-19-30", DrawDate =  DateTime.Parse("1/4/2021")},
                new MegaLotto645 {Combination = "45-07-28-33-02-27", DrawDate =  DateTime.Parse("1/6/2021")},
                new MegaLotto645 {Combination = "25-16-39-12-07-02", DrawDate =  DateTime.Parse("1/8/2021")},
                new MegaLotto645 {Combination = "21-42-17-20-37-01", DrawDate =  DateTime.Parse("1/11/2021")},
                new MegaLotto645 {Combination = "19-12-18-22-44-09", DrawDate =  DateTime.Parse("1/13/2021")},
                new MegaLotto645 {Combination = "38-14-21-17-04-08", DrawDate =  DateTime.Parse("1/15/2021")},
                new MegaLotto645 {Combination = "09-04-45-01-31-35", DrawDate =  DateTime.Parse("1/18/2021")},
                new MegaLotto645 {Combination = "33-42-40-01-20-25", DrawDate =  DateTime.Parse("1/20/2021")},
                new MegaLotto645 {Combination = "41-27-07-26-44-42", DrawDate =  DateTime.Parse("1/22/2021")},
                new MegaLotto645 {Combination = "30-18-24-13-23-34", DrawDate =  DateTime.Parse("1/25/2021")},
                new MegaLotto645 {Combination = "07-10-29-32-12-35", DrawDate =  DateTime.Parse("1/27/2021")},
                new MegaLotto645 {Combination = "27-36-17-42-23-14", DrawDate =  DateTime.Parse("1/29/2021")},
                new MegaLotto645 {Combination = "01-25-12-06-37-41", DrawDate =  DateTime.Parse("2/1/2021")},
                new MegaLotto645 {Combination = "35-39-38-33-03-30", DrawDate =  DateTime.Parse("2/3/2021")},
                new MegaLotto645 {Combination = "18-19-04-13-29-06", DrawDate =  DateTime.Parse("2/5/2021")},
                new MegaLotto645 {Combination = "31-36-22-35-42-05", DrawDate =  DateTime.Parse("2/8/2021")},
                new MegaLotto645 {Combination = "17-45-16-29-38-04", DrawDate =  DateTime.Parse("2/10/2021")},
                new MegaLotto645 {Combination = "20-09-29-27-30-33", DrawDate =  DateTime.Parse("2/12/2021")},
                new MegaLotto645 {Combination = "16-44-40-32-43-38", DrawDate =  DateTime.Parse("2/15/2021")},
            };

            var superLotto649 = new List<SuperLotto649>
            {
                new SuperLotto649 {  Combination = "06-12-18-20-32-41", DrawDate =  DateTime.Parse("12/6/2020")},
                new SuperLotto649 {Combination = "24-03-49-08-28-05", DrawDate =  DateTime.Parse("12/20/2020")},
                new SuperLotto649 {Combination = "24-07-20-27-35-09", DrawDate =  DateTime.Parse("12/22/2020")},
                new SuperLotto649 {Combination = "10-27-15-34-07-20", DrawDate =  DateTime.Parse("12/24/2020")},
                new SuperLotto649 {Combination = "23-19-16-38-09-08", DrawDate =  DateTime.Parse("12/27/2020")},
                new SuperLotto649 {Combination = "37-45-25-14-44-26", DrawDate =  DateTime.Parse("12/29/2020")},
                new SuperLotto649 {Combination = "11-32-04-29-22-02", DrawDate =  DateTime.Parse("12/31/2020")},
                new SuperLotto649 {Combination = "33-24-49-11-29-01", DrawDate =  DateTime.Parse("1/3/2021")},
                new SuperLotto649 {Combination = "30-31-10-13-11-14", DrawDate =  DateTime.Parse("1/5/2021")},
                new SuperLotto649 {Combination = "16-40-37-23-20-26", DrawDate =  DateTime.Parse("1/7/2021")},
                new SuperLotto649 {Combination = "10-44-33-28-42-04", DrawDate =  DateTime.Parse("1/10/2021")},
                new SuperLotto649 {Combination = "26-43-42-05-29-41", DrawDate =  DateTime.Parse("1/12/2021")},
                new SuperLotto649 {Combination = "16-47-14-44-35-21", DrawDate =  DateTime.Parse("1/14/2021")},
                new SuperLotto649 {Combination = "35-42-33-05-20-22", DrawDate =  DateTime.Parse("1/17/2021")},
                new SuperLotto649 {Combination = "07-15-01-38-26-41", DrawDate =  DateTime.Parse("1/19/2021")},
                new SuperLotto649 {Combination = "15-39-19-03-46-26", DrawDate =  DateTime.Parse("1/21/2021")},
                new SuperLotto649 {Combination = "33-16-28-13-38-49", DrawDate =  DateTime.Parse("1/24/2021")},
                new SuperLotto649 {Combination = "10-31-37-08-47-21", DrawDate =  DateTime.Parse("1/26/2021")},
                new SuperLotto649 {Combination = "47-42-29-17-11-32", DrawDate =  DateTime.Parse("1/28/2021")},
                new SuperLotto649 {Combination = "22-09-30-48-01-14", DrawDate =  DateTime.Parse("1/31/2021")},
                new SuperLotto649 {Combination = "36-05-26-44-42-46", DrawDate =  DateTime.Parse("2/2/2021")},
                new SuperLotto649 {Combination = "48-12-29-37-47-34", DrawDate =  DateTime.Parse("2/4/2021")},
                new SuperLotto649 {Combination = "21-04-10-31-47-49", DrawDate =  DateTime.Parse("2/7/2021")},
                new SuperLotto649 {Combination = "47-16-12-07-24-22", DrawDate =  DateTime.Parse("2/9/2021")},
                new SuperLotto649 {Combination = "36-03-27-17-33-05", DrawDate =  DateTime.Parse("2/11/2021")},
                new SuperLotto649 {Combination = "29-47-36-39-35-30", DrawDate =  DateTime.Parse("2/14/2021")},
                new SuperLotto649 {Combination = "15-01-09-44-46-41", DrawDate =  DateTime.Parse("2/16/2021")},

            };

            var grandLotto655 = new List<GrandLotto655>
            {
                new GrandLotto655 {Combination = "05-10-42-50-27-41", DrawDate =  DateTime.Parse("12/2/2020")},
                new GrandLotto655 {Combination = "42-07-43-18-37-38", DrawDate =  DateTime.Parse("12/21/2020")},
                new GrandLotto655 {Combination = "09-25-55-34-05-02", DrawDate =  DateTime.Parse("12/23/2020")},
                new GrandLotto655 {Combination = "55-50-48-21-18-54", DrawDate =  DateTime.Parse("12/26/2020")},
                new GrandLotto655 {Combination = "28-53-32-54-50-14", DrawDate =  DateTime.Parse("12/28/2020")},
                new GrandLotto655 {Combination = "47-17-50-39-30-55", DrawDate =  DateTime.Parse("12/30/2020")},
                new GrandLotto655 {Combination = "36-35-48-37-51-04", DrawDate =  DateTime.Parse("1/2/2021")},
                new GrandLotto655 {Combination = "01-11-35-54-41-24", DrawDate =  DateTime.Parse("1/4/2021")},
                new GrandLotto655 {Combination = "51-45-41-16-43-07", DrawDate =  DateTime.Parse("1/6/2021")},
                new GrandLotto655 {Combination = "22-15-53-07-05-38", DrawDate =  DateTime.Parse("1/9/2021")},
                new GrandLotto655 {Combination = "46-44-36-35-43-41", DrawDate =  DateTime.Parse("1/11/2021")},
                new GrandLotto655 {Combination = "44-03-33-23-43-07", DrawDate =  DateTime.Parse("1/13/2021")},
                new GrandLotto655 {Combination = "27-49-47-25-54-29", DrawDate =  DateTime.Parse("1/16/2021")},
                new GrandLotto655 {Combination = "23-44-22-26-16-12", DrawDate =  DateTime.Parse("1/18/2021")},
                new GrandLotto655 {Combination = "53-15-09-12-41-16", DrawDate =  DateTime.Parse("1/20/2021")},
                new GrandLotto655 {Combination = "45-30-35-36-21-10", DrawDate =  DateTime.Parse("1/23/2021")},
                new GrandLotto655 {Combination = "30-11-47-24-54-48", DrawDate =  DateTime.Parse("1/25/2021")},
                new GrandLotto655 {Combination = "40-41-20-37-52-11", DrawDate =  DateTime.Parse("1/27/2021")},
                new GrandLotto655 {Combination = "10-26-31-16-17-01", DrawDate =  DateTime.Parse("1/30/2021")},
                new GrandLotto655 {Combination = "31-20-32-29-17-48", DrawDate =  DateTime.Parse("2/1/2021")},
                new GrandLotto655 {Combination = "01-14-10-25-51-38", DrawDate =  DateTime.Parse("2/3/2021")},
                new GrandLotto655 {Combination = "16-53-46-49-51-29", DrawDate =  DateTime.Parse("2/6/2021")},
                new GrandLotto655 {Combination = "30-02-05-23-06-24", DrawDate =  DateTime.Parse("2/8/2021")},
                new GrandLotto655 {Combination = "01-02-46-47-11-32", DrawDate =  DateTime.Parse("2/10/2021")},
                new GrandLotto655 {Combination = "27-14-18-13-03-46", DrawDate =  DateTime.Parse("2/13/2021")},
                new GrandLotto655 {Combination = "36-14-44-39-22-40", DrawDate =  DateTime.Parse("2/15/2021")},

            };
            var ultraLotto658 = new List<UltraLotto658>
            {
                new UltraLotto658 {Combination = "19-09-52-55-31-54", DrawDate =  DateTime.Parse("12/6/2020")},
                new UltraLotto658 {Combination = "34-38-46-22-48-52", DrawDate =  DateTime.Parse("12/20/2020")},
                new UltraLotto658 {Combination = "09-45-51-15-42-36", DrawDate =  DateTime.Parse("12/22/2020")},
                new UltraLotto658 {Combination = "21-57-33-32-39-49", DrawDate =  DateTime.Parse("12/27/2020")},
                new UltraLotto658 {Combination = "19-38-48-30-06-46", DrawDate =  DateTime.Parse("12/29/2020")},
                new UltraLotto658 {Combination = "29-06-19-38-27-58", DrawDate =  DateTime.Parse("1/3/2021")},
                new UltraLotto658 {Combination = "28-01-05-30-15-32", DrawDate =  DateTime.Parse("1/5/2021")},
                new UltraLotto658 {Combination = "52-26-50-44-06-45", DrawDate =  DateTime.Parse("1/8/2021")},
                new UltraLotto658 {Combination = "22-30-28-39-05-19", DrawDate =  DateTime.Parse("1/10/2021")},
                new UltraLotto658 {Combination = "38-54-47-48-42-25", DrawDate =  DateTime.Parse("1/12/2021")},
                new UltraLotto658 {Combination = "07-53-54-09-50-29", DrawDate =  DateTime.Parse("1/15/2021")},
                new UltraLotto658 {Combination = "39-29-17-05-37-01", DrawDate =  DateTime.Parse("1/17/2021")},
                new UltraLotto658 {Combination = "20-46-48-44-10-50", DrawDate =  DateTime.Parse("1/19/2021")},
                new UltraLotto658 {Combination = "19-07-56-24-28-43", DrawDate =  DateTime.Parse("1/22/2021")},
                new UltraLotto658 {Combination = "57-21-47-33-27-05", DrawDate =  DateTime.Parse("1/24/2021")},
                new UltraLotto658 {Combination = "02-42-11-29-56-21", DrawDate =  DateTime.Parse("1/26/2021")},
                new UltraLotto658 {Combination = "34-10-26-04-42-21", DrawDate =  DateTime.Parse("1/29/2021")},
                new UltraLotto658 {Combination = "11-05-19-49-17-35", DrawDate =  DateTime.Parse("1/31/2021")},
                new UltraLotto658 {Combination = "37-29-33-51-42-13", DrawDate =  DateTime.Parse("2/2/2021")},
                new UltraLotto658 {Combination = "26-01-44-40-03-36", DrawDate =  DateTime.Parse("2/5/2021")},
                new UltraLotto658 {Combination = "11-12-01-56-48-38", DrawDate =  DateTime.Parse("2/7/2021")},
                new UltraLotto658 {Combination = "43-09-21-18-20-31", DrawDate =  DateTime.Parse("2/9/2021")},
                new UltraLotto658 {Combination = "24-09-32-41-29-22", DrawDate =  DateTime.Parse("2/12/2021")},
                new UltraLotto658 {Combination = "53-51-46-31-26-07", DrawDate =  DateTime.Parse("2/14/2021")},
                new UltraLotto658 {Combination = "04-35-07-26-23-14", DrawDate =  DateTime.Parse("2/16/2021")},
            };

            foreach (var i in lotto642)
            {
                if (!string.IsNullOrWhiteSpace(i.Combination))
                {
                    await DataRepository.AddLotto642Async(i).ConfigureAwait(false);
                }
            }

            foreach (var i in megaLotto645)
            {
                if (!string.IsNullOrWhiteSpace(i.Combination))
                {
                    await DataRepository.AddMegaLotto645Async(i).ConfigureAwait(false);
                }
            }

            foreach (var i in superLotto649)
            {
                if (!string.IsNullOrWhiteSpace(i.Combination))
                {
                    await DataRepository.AddSuperLotto649Async(i).ConfigureAwait(false);
                }
            }

            foreach (var i in grandLotto655)
            {
                if (!string.IsNullOrWhiteSpace(i.Combination))
                {
                    await DataRepository.AddGrandLotto655Async(i).ConfigureAwait(false);
                }
            }

            foreach (var i in ultraLotto658)
            {
                if (!string.IsNullOrWhiteSpace(i.Combination))
                {
                    await DataRepository.AddUltraLotto658Async(i).ConfigureAwait(false);
                }
            }

        }

        private static string SortDigit(string combination)
        {
            var combinationArr = combination.Replace(Environment.NewLine, string.Empty).Split('-');

            return string.Join("-", combinationArr.OrderBy(c => int.Parse(c)));
        }
    }
}
