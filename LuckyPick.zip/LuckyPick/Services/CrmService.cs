﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using LuckyPick.Data;
using LuckyPick.Repository;
using System.Threading.Tasks;

namespace LuckyPick.Services
{
    public class CrmService
    {

        public static void Export(string input)
        {
            string path = $@"C:\Crm";
            string gamePath = path + $@"\crm.txt";

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            if (!File.Exists(gamePath))
            {
                using (StreamWriter sw = File.CreateText(gamePath))
                {
                    sw.WriteLine(input);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(gamePath))
                {
                    sw.WriteLine(input);
                }
            }
        }

        public static void Generate()
        {
            var strData = crmData.Data();
            var digitArr = strData.Replace(Environment.NewLine, string.Empty).Split(',');

            foreach (var item in digitArr)
            {
               var arr = item.Split(' ');

                var str = $@"DELETE FROM [crm].[ProgramCommunicationXref] WHERE WHERE CommunicationTypeId = 2 AND CoverKey = {arr[0]} AND LocKey = {arr[1]};";

                Export(str);
            }
        }

    }
}
