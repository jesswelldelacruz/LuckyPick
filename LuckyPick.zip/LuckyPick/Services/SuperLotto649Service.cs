﻿using LuckyPick.Data;
using LuckyPick.Repository;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LuckyPick.Services
{
    public class SuperLotto649Service
    {
        public async static Task LuckyPick(int div)
        {
            var data = new List<string>();
            //var sortData = DataRepository.GetAll649();
            var allSortData = await LuckyPickService.GetAllSortData().ConfigureAwait(true);
            var allConsecutiveData = await LuckyPickService.GetAllConsecutiveData().ConfigureAwait(true);
            var allSameData = await LuckyPickService.GetAllSameDigitData().ConfigureAwait(true);

            data.AddRange(allSortData);
            data.AddRange(allConsecutiveData);
            data.AddRange(allSameData);

            for (int i = 0; i < div; i++)
            {
                var luckyPick = LuckyPickService.Generate(6, 49);

                while (data.Contains(luckyPick))
                {
                    luckyPick = LuckyPickService.Generate(6, 49);
                }

                LuckyPickService.Export("SuperLotto649", luckyPick);
                Console.WriteLine(luckyPick);
            }
        }
    }
}
