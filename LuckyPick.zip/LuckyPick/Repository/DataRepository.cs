﻿using LuckyPick.Infra.Context;
using System.Linq;
using LuckyPick.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LuckyPick.Repository
{
    public class DataRepository
    {
        public async static Task<List<string>> GetAll642()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context.Lotto642.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAll645()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context.MegaLotto645.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAll649()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context.SuperLotto649.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAll655()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context.GrandLotto655.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAll658()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context.UltraLotto658.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_2()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_2.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_3()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_3.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_4()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_4.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_5()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_5.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_6()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_6.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_7()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_7.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_8()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_8.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_9()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_9.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_10()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_10.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_11()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_11.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_12()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_12.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_13()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_13.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllConsecutives_14()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._Consecutives_14.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllSameDigits()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._SameDigit.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        public async static Task<List<string>> GetAllSameLastDigits()
        {
            var data = new List<string>();
            using (var context = new LuckyPickContext())
            {
                var res = await context._SameLastDigit.ToListAsync().ConfigureAwait(true);
                res.ForEach(x => data.Add(SortDigit(x.Combination)));
                return data;
            }
        }

        private static string SortDigit(string combination)
        {
            var combinationArr = combination.Replace(Environment.NewLine, string.Empty).Split('-');

            return string.Join("-", combinationArr.OrderBy(c => int.Parse(c)));
        }

        public async static Task AddLotto642Async(Lotto642 lotto642)
        {
            try
            {
                using (var context = new LuckyPickContext())
                {
                    var res = await context.Lotto642.FindAsync(lotto642.Combination).ConfigureAwait(true);

                    if (res == null)
                    {
                        context.Lotto642.Add(lotto642);
                        context.SaveChanges();
                    }
                    else
                    {
                        Console.WriteLine($"{lotto642.Combination} is already exist");
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async static Task AddMegaLotto645Async(MegaLotto645 megaLotto645)
        {
            try
            {
                using (var context = new LuckyPickContext())
                {
                    var res = await context.MegaLotto645.FindAsync(megaLotto645.Combination).ConfigureAwait(true);
                    
                    if (res == null)
                    {
                        context.MegaLotto645.Add(megaLotto645);
                        context.SaveChanges();
                    }
                    else
                    {
                        Console.WriteLine($"{megaLotto645.Combination} is already exist");
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async static Task AddSuperLotto649Async(SuperLotto649 superLotto649)
        {
            try
            {
                using (var context = new LuckyPickContext())
                {
                    var res = await context.SuperLotto649.FindAsync(superLotto649.Combination).ConfigureAwait(true);

                    if (res == null)
                    {
                        context.SuperLotto649.Add(superLotto649);
                        context.SaveChanges();
                    }
                    else
                    {
                        Console.WriteLine($"{superLotto649.Combination} is already exist");
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async static Task AddGrandLotto655Async(GrandLotto655 grandLotto655)
        {
            try
            {
                using (var context = new LuckyPickContext())
                {
                    var res = await context.GrandLotto655.FindAsync(grandLotto655.Combination).ConfigureAwait(true);

                    if (res == null)
                    {
                        context.GrandLotto655.Add(grandLotto655);
                        context.SaveChanges();
                    }
                    else
                    {
                        Console.WriteLine($"{grandLotto655.Combination} is already exist");
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async static Task AddUltraLotto658Async(UltraLotto658 ultraLotto658)
        {
            try
            {
                using (var context = new LuckyPickContext())
                {
                    var res = await context.UltraLotto658.FindAsync(ultraLotto658.Combination).ConfigureAwait(true);

                    if (res == null)
                    {
                        context.UltraLotto658.Add(ultraLotto658);
                        context.SaveChanges();
                    }
                    else
                    {
                        Console.WriteLine($"{ultraLotto658.Combination} is already exist");
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
