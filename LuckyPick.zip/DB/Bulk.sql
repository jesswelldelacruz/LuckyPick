CREATE TABLE [dbo].[SuperLotto649]
(
	[Id] INT IDENTITY(1,1) NOT NULL,
    [Combination] NVARCHAR(50) NOT NULL,
	[DrawDate] DATETIME NOT NULL

) ON [PRIMARY]

CREATE TABLE [dbo].[Lotto_Staging]
(
    [Combination] NVARCHAR(50) NOT NULL,
	[DrawDate] DATETIME NOT NULL

) ON [PRIMARY]

INSERT INTO dbo.[Consecutives](Digits) 
   SELECT Digits
   FROM dbo.[Consecutives_Staging]

BULK
INSERT dbo._SameLastDigit
FROM 'C:\\Lotto\\SameDigit2.txt' --location with filename
WITH
(
FIELDTERMINATOR = '""',
ROWTERMINATOR = '\n'
)
GO

select * from dbo.Lotto642 
select * from dbo.[MegaLotto645] 
select * from dbo.GrandLotto655 
select * from dbo.SuperLotto649 
select * from dbo.[UltraLotto658] 