CREATE DATABASE [LuckyPick];
GO

USE [LuckyPick]
GO
/****** Object:  Table [dbo].[Consecutives]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_10]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_10](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_11]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_11](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_12]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_12](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_13]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_13](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_14]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_14](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_2]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_2](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_3]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_3](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_4]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_4](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_5]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_5](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_6]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_6](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_7]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_7](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_8]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_8](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Consecutives_9]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_Consecutives_9](
	[Combination] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[GrandLotto655]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GrandLotto655](
    [Combination] NVARCHAR(50) NOT NULL,
	[DrawDate] DATETIME NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Lotto642]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Lotto642](
    [Combination] NVARCHAR(50) NOT NULL,
	[DrawDate] DATETIME NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MegaLotto645]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MegaLotto645](
    [Combination] NVARCHAR(50) NOT NULL,
	[DrawDate] DATETIME NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SameDigit]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_SameDigit](
    [Combination] NVARCHAR(50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SameLastDigit]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_SameLastDigit](
    [Combination] NVARCHAR(50) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SuperLotto649]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SuperLotto649](
    [Combination] NVARCHAR(50) NOT NULL,
	[DrawDate] DATETIME NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UltraLotto658]    Script Date: 11/5/2020 6:53:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UltraLotto658](
    [Combination] NVARCHAR(50) NOT NULL,
	[DrawDate] DATETIME NOT NULL
) ON [PRIMARY]
GO
