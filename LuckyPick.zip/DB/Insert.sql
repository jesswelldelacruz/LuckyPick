DECLARE @digit AS NVARCHAR(50);
SET @digit = '47-07-32-13-40-23';

--select * from [dbo].GrandLotto655 where Digits = @digit

IF NOT EXISTS (SELECT 1 FROM [dbo].SuperLotto649 WHERE [Digits] = @digit)
BEGIN
INSERT INTO [dbo].SuperLotto649 (Digits)
VALUES (@digit);
END




--[Lotto642]
--[MegaLotto645]
--[SuperLotto649]
--[GrandLotto655]
--[UltraLotto658]