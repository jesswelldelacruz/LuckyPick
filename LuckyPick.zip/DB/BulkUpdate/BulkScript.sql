BULK
INSERT dbo.[GrandLotto655] 
FROM 'C:\\Lotto\\655.txt'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
GO

BULK
INSERT dbo.[Lotto642] 
FROM 'C:\\Lotto\\642.txt'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
GO

BULK
INSERT dbo.[MegaLotto645] 
FROM 'C:\\Lotto\\645.txt'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
GO

BULK
INSERT dbo.[SuperLotto649] 
FROM 'C:\\Lotto\\649.txt'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
GO

BULK
INSERT dbo.[UltraLotto658] 
FROM 'C:\\Lotto\\658.txt'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
GO